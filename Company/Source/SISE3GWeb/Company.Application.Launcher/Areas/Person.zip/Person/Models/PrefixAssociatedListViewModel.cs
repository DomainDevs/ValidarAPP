﻿namespace Sistran.Core.Framework.UIF.Web.Areas.Person.Models
{
    public class PrefixAssociatedListViewModel
    {
        /// <summary>
        /// Si el documento fue recibido
        /// </summary>
        public bool IsAssociated { get; set; }
        /// <summary>
        /// Documento
        /// </summary>
        public string Branch { get; set; }
    }
}